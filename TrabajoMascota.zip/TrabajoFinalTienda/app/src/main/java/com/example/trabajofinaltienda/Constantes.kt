package com.example.trabajofinaltienda

class Constantes {

    fun obtenerTiempoD() : Long{
        return System.currentTimeMillis()
    }
}